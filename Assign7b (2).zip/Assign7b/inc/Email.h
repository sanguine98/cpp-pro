#include <iostream>
#include <fstream>
#include <cstring>
//#include <cctypes>
#define MAXBUFF 1024

using namespace std;

string email;
void WriteTheFile();
void ReadTheFile();

bool isChar();
bool isDigit(); 
bool isValidEmail();

void Dispfile();
