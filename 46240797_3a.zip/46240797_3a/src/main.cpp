#include <header.h>

int main()
{

	Employee Emp, E1();
	 
	cout<<"\nEmployee Details:"<<endl;
	Employee E2("Emp1", "ABCD", "S1", 8 ,9, 1996, 30000);
	cout<<endl;
	Employee E4("Emp2", "BCDA", "S2", 3, 4, 1997, 35000);
	cout<<endl;
	Employee E5("Emp3", "CDAB", "S1", 5, 6, 1998, 40000);
	cout<<endl;
	Employee E6("Emp4", "DCBA", "S2", 9, 10, 1999, 45000);

	Emp.GetSupervisorReportees(E2, E4, E5, E6);
	cout<<endl;
	Emp.Operator();

        cout<<endl;
	
	E2.Update();
	cout<<"\nUpdated Details:";
	E2.Display();

	Employee E3 = E2;
	cout<<"\nCopy Constructor";
	E3.Display();


	return 0;
}
