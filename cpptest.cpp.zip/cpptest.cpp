#include<iostream>
#include<bitset>
#include <sys/types.h>
#include <unistd.h>
#include <sys/wait.h>

using namespace std;

int main ( int argc, char* argv[] )
{
int pid, fpid,i, ppid,N,status,exitstatus;
fpid = fork ();
pid = getpid();
   ppid = getppid();
    if (argc == 1)
        cout<<"wait for the results"<<endl;
    {
sleep(5);
if(fork() == 0)
{
    wait(&status);
cout<<"child started"<<endl;
for(N=4;N<20;N++)
if(N%2 != 0)
cout<<"odd"<<N<<endl;
cout<<"child has ended"<<endl;
exit(3);
    
}

else
{
sleep(1);
cout<<"parent starts"<<endl;
for(N=4;N<20;N++)
if(N%2 == 0)
cout<<"even"<<N<<endl;
cout<<"parent has ended"<<endl;
}
        }
wait(0);
    cout<<"parent ending"<<endl;
    cout<<"EXIT_SUCCESS"<<endl;
    return (0);
    }
